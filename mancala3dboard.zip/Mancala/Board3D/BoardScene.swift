#if !os(visionOS)
import RealityKit
import SwiftUI
import simd

#if canImport(UIKit)
import UIKit
private typealias PlatformColor = UIColor
#else
import AppKit
private typealias PlatformColor = NSColor
#endif

/// Tags a tap-target entity with the `MancalaGame.pits` index it represents.
struct PitIndexComponent: Component {
    let index: Int
}

/// Owns the RealityKit entity graph for the 3D board: the carved slab, the
/// camera rig, lights, stones, highlight rings, and the sowing animation.
/// `Board3DView` forwards SwiftUI state here; game logic stays in
/// `MancalaGame`/`ContentView` and this class only mirrors it visually.
@MainActor
final class BoardScene {
    var onPitTapped: ((Int) -> Void)?

    private let root = Entity()
    private let cameraRig = Entity()
    private let camera = PerspectiveCamera()
    private let boardRoot = Entity()
    private let iblEntity = Entity()
    private let keyLight = Entity()

    private var stones: [[Entity]] = Array(repeating: [], count: 14)
    private var highlightRings: [ModelEntity] = []
    private var labelAnchors: [Entity] = []

    private var lightEnvironment: EnvironmentResource?
    private var darkEnvironment: EnvironmentResource?

    private var playableMaterial = UnlitMaterial()
    private var hintMaterial = UnlitMaterial()
    private var storeMaterial = UnlitMaterial()

    private(set) var isBuilt = false

    // Mirrored view state, so `sync` is cheap to call repeatedly.
    private var appliedPits: [Int] = []
    private var appliedPlayable: Set<Int> = []
    private var appliedHinted: Int?
    private var appliedStore: Int?
    private var flipped = false
    private var portrait = false
    private var viewSize = CGSize(width: 1, height: 1)
    private var labelsVisible = true
    private var isDark = false
    private var parallaxYaw: Float = 0
    private var parallaxPitch: Float = 0

    /// Camera elevation, matching the feel of the 2D board's fixed tilt.
    private let basePitch: Float = -0.66 // ≈ 38° looking down
    private let fieldOfViewDegrees: Float = 40

    // Pending state delivered before `build` finished.
    private struct PendingSync {
        var pits: [Int]
        var playable: Set<Int>
        var hinted: Int?
        var currentStore: Int?
        var flipped: Bool
        var portrait: Bool
        var viewSize: CGSize
        var showLabels: Bool
        var dark: Bool
    }
    private var pendingSync: PendingSync?

    // MARK: - Build

    /// Builds the full entity graph (idempotent) and returns the root for
    /// `Board3DView` to add to the RealityView content.
    func buildRoot() async -> Entity {
        guard !isBuilt else {
            return root
        }
        PitIndexComponent.registerComponent()

        // Heavy procedural work: slab mesh, ring meshes, wood texture, and
        // both lighting environments, all generated off the main actor.
        let slabDataTask = Task.detached(priority: .userInitiated) {
            BoardMeshBuilder.slabMeshData()
        }
        let ringDataTask = Task.detached(priority: .userInitiated) {
            BoardLayout3D.wells.map { BoardMeshBuilder.ringMeshData(around: $0) }
        }
        let woodImageTask = Task.detached(priority: .userInitiated) {
            BoardTextureBuilder.woodBaseColor()
        }
        let lightEnvImageTask = Task.detached(priority: .userInitiated) {
            BoardTextureBuilder.environmentEquirect(dark: false)
        }
        let darkEnvImageTask = Task.detached(priority: .userInitiated) {
            BoardTextureBuilder.environmentEquirect(dark: true)
        }

        let slabData = await slabDataTask.value
        let ringData = await ringDataTask.value
        let woodImage = await woodImageTask.value
        let lightEnvImage = await lightEnvImageTask.value
        let darkEnvImage = await darkEnvImageTask.value

        // Slab.
        do {
            let slabMesh = try await MeshResource(from: [BoardMeshBuilder.descriptor(from: slabData, name: "boardSlab")])
            var wood = PhysicallyBasedMaterial()
            if let woodImage {
                let texture = try await TextureResource(
                    image: woodImage,
                    options: .init(semantic: .color)
                )
                wood.baseColor = .init(texture: .init(texture))
            } else {
                wood.baseColor = .init(tint: PlatformColor(red: 0.42, green: 0.27, blue: 0.16, alpha: 1))
            }
            wood.roughness = 0.5
            wood.metallic = 0.0
            wood.clearcoat = 0.3
            wood.clearcoatRoughness = 0.4
            let slab = ModelEntity(mesh: slabMesh, materials: [wood])
            boardRoot.addChild(slab)
        } catch {
            assertionFailure("Board slab generation failed: \(error)")
        }

        // Highlight rings, one per well, hidden until needed. Vertices are in
        // absolute board coordinates, so the entities sit at the origin.
        playableMaterial = makeRingMaterial(PlatformColor(red: 0.35, green: 0.80, blue: 1.0, alpha: 1), opacity: 0.85)
        hintMaterial = makeRingMaterial(PlatformColor(red: 1.0, green: 0.84, blue: 0.20, alpha: 1), opacity: 0.95)
        storeMaterial = makeRingMaterial(PlatformColor(red: 0.30, green: 0.85, blue: 0.45, alpha: 1), opacity: 0.7)
        highlightRings = []
        for data in ringData {
            do {
                let mesh = try await MeshResource(from: [BoardMeshBuilder.descriptor(from: data, name: "highlightRing")])
                let ring = ModelEntity(mesh: mesh, materials: [playableMaterial])
                ring.isEnabled = false
                boardRoot.addChild(ring)
                highlightRings.append(ring)
            } catch {
                highlightRings.append(ModelEntity())
            }
        }

        // Tap targets and label anchors per well.
        labelAnchors = []
        for (index, well) in BoardLayout3D.wells.enumerated() {
            let isStore = well.axisHalfLength > 0
            if !isStore {
                let target = Entity()
                target.position = SIMD3(well.center.x, 0, well.center.y)
                target.components.set(CollisionComponent(shapes: [.generateSphere(radius: well.radius * 1.1)]))
                target.components.set(InputTargetComponent())
                target.components.set(PitIndexComponent(index: index))
                boardRoot.addChild(target)
            }

            let labelAnchor = Entity()
            let outward: SIMD2<Float> = isStore
                ? SIMD2(well.center.x > 0 ? 0.055 : -0.055, 0)
                : SIMD2(0, well.center.y > 0 ? 0.042 : -0.042)
            labelAnchor.position = SIMD3(well.center.x + outward.x, 0.035, well.center.y + outward.y)
            boardRoot.addChild(labelAnchor)
            labelAnchors.append(labelAnchor)
        }

        // Lighting: image-based light for the glass/varnish reflections plus
        // a shadow-casting key light for stone grounding.
        do {
            if let lightEnvImage {
                lightEnvironment = try await EnvironmentResource(equirectangular: lightEnvImage)
            }
            if let darkEnvImage {
                darkEnvironment = try await EnvironmentResource(equirectangular: darkEnvImage)
            }
        } catch {
            assertionFailure("Environment generation failed: \(error)")
        }
        if let environment = isDark ? (darkEnvironment ?? lightEnvironment) : lightEnvironment {
            iblEntity.components.set(ImageBasedLightComponent(source: .single(environment), intensityExponent: 0.9))
            root.components.set(ImageBasedLightReceiverComponent(imageBasedLight: iblEntity))
        }
        root.addChild(iblEntity)

        keyLight.components.set(DirectionalLightComponent(color: .white, intensity: isDark ? 1700 : 2600))
        keyLight.components.set(DirectionalLightComponent.Shadow())
        keyLight.orientation = simd_quatf(angle: -0.95, axis: SIMD3(1, 0, 0))
            * simd_quatf(angle: 0.5, axis: SIMD3(0, 1, 0))
        root.addChild(keyLight)

        // Camera rig: pivot at the board center; parallax and the base pitch
        // both rotate the rig, so the camera orbits the board like a viewer
        // leaning around a physical object.
        camera.camera.fieldOfViewInDegrees = fieldOfViewDegrees
        cameraRig.addChild(camera)
        root.addChild(cameraRig)

        root.addChild(boardRoot)

        isBuilt = true
        if let pending = pendingSync {
            pendingSync = nil
            sync(
                pits: pending.pits,
                playable: pending.playable,
                hinted: pending.hinted,
                currentStore: pending.currentStore,
                flipped: pending.flipped,
                portrait: pending.portrait,
                viewSize: pending.viewSize,
                showLabels: pending.showLabels,
                dark: pending.dark
            )
        } else {
            updateBoardOrientation(animated: false)
            updateCamera()
        }
        return root
    }

    private func makeRingMaterial(_ color: PlatformColor, opacity: Float) -> UnlitMaterial {
        var material = UnlitMaterial(color: color)
        material.blending = .transparent(opacity: .init(floatLiteral: opacity))
        material.faceCulling = .none
        return material
    }

    /// Called by `Board3DView` once attachments exist: parents each count
    /// label to its well and keeps it facing the camera.
    func attachLabel(_ entity: Entity, forPit index: Int) {
        guard labelAnchors.indices.contains(index), entity.parent !== labelAnchors[index] else { return }
        entity.components.set(BillboardComponent())
        labelAnchors[index].addChild(entity)
        entity.setPosition(.zero, relativeTo: labelAnchors[index])
    }

    // MARK: - State sync

    /// Idempotent mirror of the SwiftUI-observed state; cheap when unchanged.
    func sync(
        pits: [Int],
        playable: Set<Int>,
        hinted: Int?,
        currentStore: Int?,
        flipped: Bool,
        portrait: Bool,
        viewSize: CGSize,
        showLabels: Bool,
        dark: Bool
    ) {
        guard isBuilt else {
            pendingSync = PendingSync(
                pits: pits,
                playable: playable,
                hinted: hinted,
                currentStore: currentStore,
                flipped: flipped,
                portrait: portrait,
                viewSize: viewSize,
                showLabels: showLabels,
                dark: dark
            )
            return
        }

        applyStones(pits: pits)
        applyHighlights(playable: playable, hinted: hinted, currentStore: currentStore)

        if flipped != self.flipped || portrait != self.portrait {
            self.flipped = flipped
            self.portrait = portrait
            updateBoardOrientation(animated: true)
            updateCamera()
        }
        if viewSize != self.viewSize {
            self.viewSize = viewSize
            updateCamera()
        }
        if showLabels != labelsVisible {
            labelsVisible = showLabels
            for anchor in labelAnchors {
                anchor.isEnabled = showLabels
            }
        }
        if dark != isDark {
            isDark = dark
            applyColorScheme()
        }
    }

    /// Reconcile stone entities against the game's pit counts, O(delta).
    /// Deterministic slots guarantee existing stones never reshuffle.
    private func applyStones(pits: [Int]) {
        guard pits.count == 14 else { return }
        guard pits != appliedPits else { return }
        appliedPits = pits

        for index in 0..<14 {
            let target = min(pits[index], BoardLayout3D.visibleStoneCap)
            var current = stones[index]
            while current.count > target {
                current.removeLast().removeFromParent()
            }
            while current.count < target {
                let stone = StoneFactory.makeRestingStone(pitIndex: index, slot: current.count)
                let restTransform = Transform(translation: stone.position)
                stone.transform.scale = SIMD3(repeating: 0.05)
                boardRoot.addChild(stone)
                stone.move(to: restTransform, relativeTo: boardRoot, duration: 0.18, timingFunction: .easeOut)
                current.append(stone)
            }
            stones[index] = current
        }
    }

    private func applyHighlights(playable: Set<Int>, hinted: Int?, currentStore: Int?) {
        guard playable != appliedPlayable || hinted != appliedHinted || currentStore != appliedStore else {
            return
        }
        appliedPlayable = playable
        appliedHinted = hinted
        appliedStore = currentStore

        for (index, ring) in highlightRings.enumerated() {
            if index == hinted {
                ring.model?.materials = [hintMaterial]
                ring.isEnabled = true
            } else if playable.contains(index) {
                ring.model?.materials = [playableMaterial]
                ring.isEnabled = true
            } else if index == currentStore {
                ring.model?.materials = [storeMaterial]
                ring.isEnabled = true
            } else {
                ring.isEnabled = false
            }
        }
    }

    private func applyColorScheme() {
        if let environment = isDark ? (darkEnvironment ?? lightEnvironment) : lightEnvironment {
            iblEntity.components.set(ImageBasedLightComponent(source: .single(environment), intensityExponent: 0.9))
        }
        keyLight.components.set(DirectionalLightComponent(color: .white, intensity: isDark ? 1700 : 2600))
    }

    /// Pass-and-play flip (180°) and portrait (-90°, so player one's store
    /// lands at the near/bottom edge) both rotate the physical board.
    private func updateBoardOrientation(animated: Bool) {
        var yaw: Float = portrait ? -.pi / 2 : 0
        if flipped {
            yaw += .pi
        }
        let transform = Transform(rotation: simd_quatf(angle: yaw, axis: SIMD3(0, 1, 0)))
        if animated {
            boardRoot.move(to: transform, relativeTo: root, duration: 0.45, timingFunction: .easeInOut)
        } else {
            boardRoot.transform = transform
        }
    }

    // MARK: - Camera

    /// Frame the board for the current viewport and apply the parallax
    /// offsets. Cheap enough to run per motion sample.
    private func updateCamera() {
        let aspect = Float(viewSize.width / max(viewSize.height, 1))
        let vFOV = fieldOfViewDegrees * .pi / 180
        let hFOV = 2 * atan(tan(vFOV / 2) * max(aspect, 0.1))

        let alongScreenX = (portrait ? BoardLayout3D.depth : BoardLayout3D.width) / 2 + 0.05
        let alongScreenY = (portrait ? BoardLayout3D.width : BoardLayout3D.depth) / 2 + 0.06
        // The board lies nearly flat, so its z-extent is foreshortened by the
        // camera pitch when projected to screen-vertical.
        let pitch = -(basePitch)
        let projectedY = alongScreenY * max(sin(pitch), 0.35) + 0.03
        let distance = max(
            alongScreenX / tan(hFOV / 2),
            projectedY / tan(vFOV / 2),
            0.35
        )

        camera.position = SIMD3(0, 0, distance)
        cameraRig.orientation = simd_quatf(angle: parallaxYaw, axis: SIMD3(0, 1, 0))
            * simd_quatf(angle: basePitch + parallaxPitch, axis: SIMD3(1, 0, 0))
    }

    /// Small smoothed offsets from device motion; the rig orbits the board
    /// center so tilting the device reads as looking around the object.
    func setParallax(yaw: Float, pitch: Float) {
        guard isBuilt else { return }
        parallaxYaw = yaw
        parallaxPitch = pitch
        updateCamera()
    }

    // MARK: - Sowing animation

    /// Fly one stone from `from` to `to` along a low arc. The caller then
    /// mutates the game model, and the resting stone appears via `sync`.
    func flyStone(from: Int, to: Int, colorIndex: Int) async {
        guard isBuilt,
              BoardLayout3D.wells.indices.contains(from),
              BoardLayout3D.wells.indices.contains(to) else {
            return
        }
        let source = BoardLayout3D.wells[from].center
        let destination = BoardLayout3D.wells[to].center
        let start = SIMD3(source.x, 0.016, source.y)
        let end = SIMD3(destination.x, 0.012, destination.y)
        let apex = (start + end) / 2 + SIMD3(0, 0.055, 0)

        let stone = StoneFactory.makeFlyingStone(colorIndex: colorIndex)
        stone.position = start
        boardRoot.addChild(stone)

        let scale = stone.transform.scale
        let rotation = stone.transform.rotation
        stone.move(
            to: Transform(scale: scale, rotation: rotation, translation: apex),
            relativeTo: boardRoot,
            duration: 0.10,
            timingFunction: .easeOut
        )
        try? await Task.sleep(for: .milliseconds(100))
        stone.move(
            to: Transform(scale: scale, rotation: rotation, translation: end),
            relativeTo: boardRoot,
            duration: 0.10,
            timingFunction: .easeIn
        )
        try? await Task.sleep(for: .milliseconds(100))
        stone.removeFromParent()
    }
}
#endif
