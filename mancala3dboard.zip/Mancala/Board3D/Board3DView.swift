#if !os(visionOS)
import RealityKit
import SwiftUI

/// SwiftUI host for the 3D board. Renders the RealityKit scene, forwards
/// observed game state into `BoardScene`, hosts the floating count labels as
/// attachments, and routes entity taps back to the game flow.
struct Board3DView: View {
    let pits: [Int]
    let playablePits: Set<Int>
    let hintedPit: Int?
    let currentStoreIndex: Int?
    let flipped: Bool
    let isPortrait: Bool
    let showLabels: Bool
    let isDarkMode: Bool
    let scene: BoardScene

    var body: some View {
        GeometryReader { geometry in
            RealityView { content, attachments in
                content.camera = .virtual
                let sceneRoot = await scene.buildRoot()
                content.add(sceneRoot)
                for index in 0..<14 {
                    if let label = attachments.entity(for: index) {
                        scene.attachLabel(label, forPit: index)
                    }
                }
                syncScene(viewSize: geometry.size)
            } update: { _, attachments in
                for index in 0..<14 {
                    if let label = attachments.entity(for: index) {
                        scene.attachLabel(label, forPit: index)
                    }
                }
                syncScene(viewSize: geometry.size)
            } attachments: {
                ForEach(0..<14, id: \.self) { index in
                    Attachment(id: index) {
                        BoardCountLabel(count: pits.indices.contains(index) ? pits[index] : 0)
                    }
                }
            }
            .gesture(
                SpatialTapGesture()
                    .targetedToAnyEntity()
                    .onEnded { value in
                        var entity: Entity? = value.entity
                        while let current = entity {
                            if let pit = current.components[PitIndexComponent.self]?.index {
                                scene.onPitTapped?(pit)
                                return
                            }
                            entity = current.parent
                        }
                    }
            )
        }
        .accessibilityLabel("Mancala board")
    }

    private func syncScene(viewSize: CGSize) {
        scene.sync(
            pits: pits,
            playable: playablePits,
            hinted: hintedPit,
            currentStore: currentStoreIndex,
            flipped: flipped,
            portrait: isPortrait,
            viewSize: viewSize,
            showLabels: showLabels,
            dark: isDarkMode
        )
    }
}

/// Floating stone-count pill above each well. Billboarded by `BoardScene`,
/// so it stays readable through flips, portrait rotation, and parallax.
private struct BoardCountLabel: View {
    let count: Int

    var body: some View {
        Text("\(count)")
            .font(.system(size: 15, weight: .semibold, design: .rounded).monospacedDigit())
            .foregroundStyle(.white)
            .padding(.horizontal, 7)
            .padding(.vertical, 2)
            .background(Capsule().fill(Color.black.opacity(0.38)))
            .contentTransition(.numericText())
            .animation(.spring(response: 0.3, dampingFraction: 0.8), value: count)
    }
}
#endif
