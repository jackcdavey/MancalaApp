import CoreGraphics
import Foundation
import simd

/// Generates the board's textures procedurally at launch (the app ships no
/// image assets for the 3D board): a walnut wood-grain base color with the
/// wells' ambient occlusion baked in, and a small equirectangular environment
/// image used for image-based lighting so the glass stones pick up bright
/// window-like reflections.
enum BoardTextureBuilder {
    // MARK: - Value noise

    private struct ValueNoise {
        private var permutation: [Int]

        init(seed: UInt64) {
            var table = Array(0..<256)
            var rng = SplitMix64(seed: seed)
            for i in (1..<256).reversed() {
                let j = Int(rng.next() % UInt64(i + 1))
                table.swapAt(i, j)
            }
            permutation = table + table
        }

        private func lattice(_ x: Int, _ y: Int) -> Float {
            Float(permutation[(permutation[x & 255] + y) & 255]) / 255
        }

        func noise(_ x: Float, _ y: Float) -> Float {
            let x0 = Int(floor(x)), y0 = Int(floor(y))
            let fx = x - floor(x), fy = y - floor(y)
            let sx = fx * fx * (3 - 2 * fx)
            let sy = fy * fy * (3 - 2 * fy)
            let n00 = lattice(x0, y0), n10 = lattice(x0 + 1, y0)
            let n01 = lattice(x0, y0 + 1), n11 = lattice(x0 + 1, y0 + 1)
            let a = n00 + (n10 - n00) * sx
            let b = n01 + (n11 - n01) * sx
            return a + (b - a) * sy
        }

        func fbm(_ x: Float, _ y: Float, octaves: Int = 3) -> Float {
            var total: Float = 0
            var amplitude: Float = 0.5
            var fx = x, fy = y
            for _ in 0..<octaves {
                total += noise(fx, fy) * amplitude
                fx *= 2.03
                fy *= 2.03
                amplitude *= 0.5
            }
            return total
        }
    }

    /// Coarse pre-sampled copy of the well depth field: ambient occlusion is
    /// low-frequency, and sampling a grid keeps the 2M-texel bake fast.
    private struct DepthField {
        let columns: Int
        let rows: Int
        let values: [Float]

        init(columns: Int = 512, rows: Int = 256) {
            self.columns = columns
            self.rows = rows
            var values = [Float](repeating: 0, count: (columns + 1) * (rows + 1))
            for row in 0...rows {
                let z = (Float(row) / Float(rows) - 0.5) * BoardLayout3D.depth
                for column in 0...columns {
                    let x = (Float(column) / Float(columns) - 0.5) * BoardLayout3D.width
                    values[row * (columns + 1) + column] = BoardLayout3D.wellDepth(at: SIMD2(x, z))
                }
            }
            self.values = values
        }

        /// Bilinear depth sample; u, v in [0, 1] over the board footprint.
        func depth(u: Float, v: Float) -> Float {
            let fx = min(max(u, 0), 1) * Float(columns)
            let fy = min(max(v, 0), 1) * Float(rows)
            let x0 = min(Int(fx), columns - 1), y0 = min(Int(fy), rows - 1)
            let sx = fx - Float(x0), sy = fy - Float(y0)
            let stride = columns + 1
            let n00 = values[y0 * stride + x0], n10 = values[y0 * stride + x0 + 1]
            let n01 = values[(y0 + 1) * stride + x0], n11 = values[(y0 + 1) * stride + x0 + 1]
            let a = n00 + (n10 - n00) * sx
            let b = n01 + (n11 - n01) * sx
            return a + (b - a) * sy
        }

        /// Magnitude of the depth gradient, for rim darkening.
        func gradientMagnitude(u: Float, v: Float) -> Float {
            let du: Float = 1.5 / Float(columns)
            let dv: Float = 1.5 / Float(rows)
            let gx = (depth(u: u + du, v: v) - depth(u: u - du, v: v)) / (2 * du * BoardLayout3D.width)
            let gz = (depth(u: u, v: v + dv) - depth(u: u, v: v - dv)) / (2 * dv * BoardLayout3D.depth)
            return sqrt(gx * gx + gz * gz)
        }
    }

    private static func makeCGImage(pixels: [UInt8], width: Int, height: Int) -> CGImage? {
        guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
              let provider = CGDataProvider(data: Data(pixels) as CFData) else {
            return nil
        }
        return CGImage(
            width: width,
            height: height,
            bitsPerComponent: 8,
            bitsPerPixel: 32,
            bytesPerRow: width * 4,
            space: colorSpace,
            bitmapInfo: CGBitmapInfo(rawValue: CGImageAlphaInfo.noneSkipLast.rawValue),
            provider: provider,
            decode: nil,
            shouldInterpolate: true,
            intent: .defaultIntent
        )
    }

    // MARK: - Wood base color with baked ambient occlusion

    /// The board mesh uses a planar UV map of the same (x, z) domain as the
    /// well depth field, so multiplying occlusion into the base color here
    /// gives physically plausible soft shadowing inside every pit with zero
    /// custom shader work.
    static func woodBaseColor(width: Int = 2048, height: Int = 1024) -> CGImage? {
        let grainNoise = ValueNoise(seed: 0xB0A2D)
        let streakNoise = ValueNoise(seed: 0x5EED5)
        let field = DepthField()
        let maxDepth = BoardLayout3D.maxWellDepth

        // Walnut palette: early wood (light) to late wood (dark rings).
        let light = SIMD3<Float>(0.52, 0.345, 0.205)
        let dark = SIMD3<Float>(0.335, 0.205, 0.115)

        var pixels = [UInt8](repeating: 255, count: width * height * 4)
        for y in 0..<height {
            let v = (Float(y) + 0.5) / Float(height)
            let pz = (v - 0.5) * BoardLayout3D.depth
            for x in 0..<width {
                let u = (Float(x) + 0.5) / Float(width)
                let px = (u - 0.5) * BoardLayout3D.width

                // Grain lines run along the board's long axis: rings vary
                // across z, waviness driven by noise along x.
                let wave = grainNoise.fbm(px * 9, pz * 40) * 9
                let ring = sin(pz * 260 + wave)
                let bands = powf(ring * 0.5 + 0.5, 1.5)
                let fineStreak = (streakNoise.fbm(px * 7, pz * 160) - 0.5) * 0.16
                let drift = (grainNoise.fbm(px * 3 + 40, pz * 3) - 0.5) * 0.12
                var color = simd_mix(light, dark, SIMD3(repeating: min(max(bands * 0.62 + fineStreak + drift + 0.12, 0), 1)))

                // Baked ambient occlusion: darker toward the bottom of each
                // well, plus extra rim contact darkening from the gradient.
                let depth = field.depth(u: u, v: v)
                let rim = min(field.gradientMagnitude(u: u, v: v) * 0.4, 1) * 0.12
                let ao = 1 - 0.55 * powf(depth / maxDepth, 0.8) - rim
                color *= max(ao, 0.22)

                let offset = (y * width + x) * 4
                pixels[offset] = UInt8(min(max(color.x, 0), 1) * 255)
                pixels[offset + 1] = UInt8(min(max(color.y, 0), 1) * 255)
                pixels[offset + 2] = UInt8(min(max(color.z, 0), 1) * 255)
            }
        }
        return makeCGImage(pixels: pixels, width: width, height: height)
    }

    // MARK: - Environment (image-based lighting)

    /// Small equirectangular environment: a soft graded sky with a few bright
    /// elongated "window" blobs. The blobs become the specular highlights on
    /// the glass stones and the sheen on the varnished wood.
    static func environmentEquirect(dark: Bool, width: Int = 256, height: Int = 128) -> CGImage? {
        struct Blob {
            let u: Float
            let v: Float
            let sigmaU: Float
            let sigmaV: Float
            let strength: Float
        }
        let blobs = [
            Blob(u: 0.22, v: 0.24, sigmaU: 0.030, sigmaV: 0.10, strength: 1.0),
            Blob(u: 0.58, v: 0.20, sigmaU: 0.045, sigmaV: 0.12, strength: 0.9),
            Blob(u: 0.86, v: 0.30, sigmaU: 0.022, sigmaV: 0.07, strength: 0.7)
        ]

        let zenith: SIMD3<Float> = dark ? SIMD3(0.10, 0.11, 0.16) : SIMD3(0.62, 0.66, 0.74)
        let horizon: SIMD3<Float> = dark ? SIMD3(0.16, 0.14, 0.17) : SIMD3(0.82, 0.76, 0.66)
        let floor: SIMD3<Float> = dark ? SIMD3(0.05, 0.045, 0.05) : SIMD3(0.30, 0.25, 0.21)
        let blobGain: Float = dark ? 0.85 : 1.0

        var pixels = [UInt8](repeating: 255, count: width * height * 4)
        for y in 0..<height {
            let v = (Float(y) + 0.5) / Float(height)
            var color: SIMD3<Float>
            if v < 0.5 {
                color = simd_mix(zenith, horizon, SIMD3(repeating: v / 0.5))
            } else {
                color = simd_mix(horizon, floor, SIMD3(repeating: min((v - 0.5) / 0.25, 1)))
            }
            for x in 0..<width {
                let u = (Float(x) + 0.5) / Float(width)
                var lit = color
                for blob in blobs {
                    var du = abs(u - blob.u)
                    du = min(du, 1 - du) // wrap around the seam
                    let dv = (v - blob.v) / blob.sigmaV
                    let dn = du / blob.sigmaU
                    lit += SIMD3(repeating: exp(-(dn * dn + dv * dv)) * blob.strength * blobGain)
                }
                let offset = (y * width + x) * 4
                pixels[offset] = UInt8(min(max(lit.x, 0), 1) * 255)
                pixels[offset + 1] = UInt8(min(max(lit.y, 0), 1) * 255)
                pixels[offset + 2] = UInt8(min(max(lit.z, 0), 1) * 255)
            }
        }
        return makeCGImage(pixels: pixels, width: width, height: height)
    }
}
